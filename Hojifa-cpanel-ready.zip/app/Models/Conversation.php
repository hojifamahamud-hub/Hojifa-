<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Conversation extends Model
{
    protected $fillable = ['user_id','name','email','type','unread'];
    protected $casts = ['unread' => 'boolean'];
    public function messages() { return $this->hasMany(Message::class); }
    public function user() { return $this->belongsTo(User::class); }
}
